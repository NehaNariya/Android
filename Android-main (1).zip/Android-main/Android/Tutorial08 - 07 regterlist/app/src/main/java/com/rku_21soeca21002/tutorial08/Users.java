package com.rku_21soeca21002.tutorial08;

public class Users {
    private String username;

    public Users(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}

package com.rku.tutorial_09;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    TextInputEditText txtnumber,txtsms;
    Button btncall,btnsms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtnumber=findViewById(R.id.txtcall);
        txtsms=findViewById(R.id.textmessage);

        btncall=findViewById(R.id.btncall);
        btnsms=findViewById(R.id.btnmessage);
    }
    public void callToNumber(View view) {
        if(isPermissionGranted(1))
        {
            call_action();
        }
    }

    public void sendTextMessage(View view)
    {
        if(isPermissionGranted(2))
        {
            sms_action();
        }
    }
    public  void  call_action()
    {
        String phonenumber=txtnumber.getText().toString();
        Intent intent=new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:"+phonenumber));
        startActivity(intent);
    }
    public  void  sms_action(){
        String phonenumber=txtnumber.getText().toString();
        String smstext=txtsms.getText().toString();
        SmsManager sms=SmsManager.getDefault();

        sms.sendTextMessage(phonenumber,null,smstext,null,null);
        Toast.makeText(getApplicationContext(),"message sent",Toast.LENGTH_SHORT).show();
    }

    public  boolean isPermissionGranted(int i){
        switch (i){
            case 1:
                if(Build.VERSION.SDK_INT>=23){
                    if(checkSelfPermission(android.Manifest.permission.CALL_PHONE)== PackageManager.PERMISSION_GRANTED) {
                        Log.v("TAG","permission is granted");
                        return  true;
                    }
                    else {
                        Log.v("TAG","permission is revoked");
                        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CALL_PHONE},1);
                        return  false;
                    }
                }else {
                    Log.v("TAG","permission is granted");
                    return  true;
                }
            case 2:
                if(Build.VERSION.SDK_INT>=23){
                    if(checkSelfPermission(Manifest.permission.SEND_SMS)==PackageManager.PERMISSION_GRANTED){
                        Log.v("TAG","sms permission is granted");
                        return  true;
                    }
                    else {
                        Log.v("TAG"," sms permission is revoked");
                        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.SEND_SMS},1);
                        return  false;
                    }
                }else {
                    Log.v("TAG","permission is granted");
                    return  true;

                }
            default:
                return false;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(getApplicationContext(), "permission granted", Toast.LENGTH_SHORT).show();
                    call_action();
                } else {
                    Toast.makeText(getApplicationContext(), "permisson denied", Toast.LENGTH_SHORT).show();

                }
                break;
            case 2:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(getApplicationContext(), "permission granted", Toast.LENGTH_SHORT).show();
                    sms_action();
                } else {
                    Toast.makeText(getApplicationContext(), "permisson denied", Toast.LENGTH_SHORT).show();

                }


            default:
                return;

        }
    }

}
package com.rku.vollydemo1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

public class UserDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_detail);

        Toast.makeText(this, ""+getIntent().getIntExtra("userid",0), Toast.LENGTH_SHORT).show();
    }
}
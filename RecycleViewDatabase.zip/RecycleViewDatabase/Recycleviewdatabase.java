# <!--activity_main.xml-->

<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    tools:context=".Dashboard">

    <androidx.recyclerview.widget.RecyclerView
        android:id="@+id/recycleView"
        android:layout_width="0dp"
        android:layout_height="0dp"
        android:layout_marginStart="8dp"
        android:layout_marginTop="8dp"
        android:layout_marginEnd="8dp"
        android:layout_marginBottom="8dp"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toTopOf="parent" />

    <com.google.android.material.floatingactionbutton.FloatingActionButton
        android:id="@+id/btnAddRecord"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginEnd="32dp"
        android:layout_marginBottom="32dp"
        android:clickable="true"
        android:src="@android:drawable/ic_menu_add"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintEnd_toEndOf="parent" />
</androidx.constraintlayout.widget.ConstraintLayout>

-----------------------------

# <!--activity_registration.xml-->

<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    tools:context=".Registration">

    <EditText
        android:id="@+id/edtUsername"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:layout_marginTop="16dp"
        android:ems="10"
        android:hint="Username"
        android:inputType="textEmailAddress"
        android:text="Ajay"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toTopOf="parent" />

    <EditText
        android:id="@+id/edtPassword"
        android:layout_width="0dp"
        android:layout_height="42dp"
        android:layout_marginTop="16dp"
        android:ems="10"
        android:hint="Password"
        android:inputType="textEmailAddress"
        android:text="123456"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toBottomOf="@+id/edtUsername" />

    <Button
        android:id="@+id/btnRegister"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="16dp"
        android:text="Register"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toBottomOf="@+id/edtPassword" />
</androidx.constraintlayout.widget.ConstraintLayout>

-----------------------------

# <!--useritem.xml-->

<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:orientation="vertical">

    <TextView
        android:id="@+id/txtUsername"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="Username"
        android:textSize="16sp"
        android:textStyle="bold" />

    <TextView
        android:id="@+id/txtPassword"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="Password"
        android:textSize="12sp"
        android:textStyle="bold" />

</LinearLayout>

--------------------------------
--------------------------------

#java

----------

# <!--Dashboard.java-->

package com.rku.databaserecycleview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class Dashboard extends AppCompatActivity {

    FloatingActionButton btnAddRecord;
    RecyclerView recyclerView;
    ArrayList<UserPOJO> users;
    UserAdapter adapter;
    DBHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        intUI();
    }

    private void intUI() {
        helper = new DBHelper(this);
        recyclerView = findViewById(R.id.recycleView);
     //   users = new ArrayList<UserPOJO>();
        users = fetchUsersFromDatabase();
        adapter = new UserAdapter(getApplicationContext(),users);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new DividerItemDecoration(Dashboard.this, DividerItemDecoration.VERTICAL));
        recyclerView.setAdapter(adapter);

        adapter.notifyDataSetChanged();

        btnAddRecord = findViewById(R.id.btnAddRecord);
        btnAddRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Dashboard.this,Registration.class));
                finish();
            }
        });
    }

    private ArrayList<UserPOJO> fetchUsersFromDatabase() {
        ArrayList<UserPOJO> usersList = new ArrayList<UserPOJO>();
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor cursor = db.query(MYUtil.TBL_NAME,null,null,null,null,null,null);

        if(cursor.getCount()>0){
            cursor.moveToFirst();
            do{
                String valuser = cursor.getString(1);
                String valpassword = cursor.getString(2);
                usersList.add(new UserPOJO(valuser,valpassword));
            }while(cursor.moveToNext());
        }
        return usersList;
    }
}


------------------------------

# <!--DBHelper.java-->

package com.rku.databaserecycleview;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context context) {
        super(context, MYUtil.DB_NAME, null, MYUtil.DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(MYUtil.SQL_CREATE_TBL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}


-------------------------------

# <!--MYUtil.java-->

package com.rku.databaserecycleview;

public class MYUtil {
    public static final String DB_NAME = "university1";
    public static final int DB_VERSION = 1;
    public static final String TBL_NAME = "student1";

    public static final String COL_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    public static final String SQL_CREATE_TBL = "" +
            "CREATE TABLE IF NOT EXISTS "+ TBL_NAME + "(" +
            COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"+
            COL_USERNAME + " VARCHAR,"+
            COL_PASSWORD + " VARCHAR)";
}


-------------------------------------

# <!--Registration.java-->

package com.rku.databaserecycleview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends AppCompatActivity {

    EditText edtUsername, edtPassword;
    Button btnRegister;
    DBHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        edtUsername = findViewById(R.id.edtUsername);
        edtPassword = findViewById(R.id.edtPassword);
        btnRegister = findViewById(R.id.btnRegister);
        helper = new DBHelper(this);
        btnRegister.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                validateForm();
            }

            private void validateForm() {
                String valUsername = edtUsername.getText().toString().trim();
                String valPassword = edtPassword.getText().toString();

                if(valUsername.equals("") || valPassword.equals("")){
                   Toast.makeText(Registration.this,"Username or Password can not empty.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(valPassword.length()<6){
                    Toast.makeText(Registration.this,"Password must be greter then 6.",Toast.LENGTH_SHORT).show();
                    return;
                }

                ContentValues values = new ContentValues();
                values.put(MYUtil.COL_USERNAME,valUsername);
                values.put(MYUtil.COL_PASSWORD,valPassword);

                SQLiteDatabase db = helper.getWritableDatabase();
                db.insert(MYUtil.TBL_NAME,null,values);
  //              db.close();
                Toast.makeText(Registration.this, "Record Added Successfully", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Registration.this, Dashboard.class));
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
   //     super.onBackPressed();
        Toast.makeText(this,"Back Button Pressed",Toast.LENGTH_SHORT).show();
    }
}

---------------------------------

# <!--UserAdapter-->

package com.rku.databaserecycleview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {

    private Context context;
    ArrayList<UserPOJO> users;

    public UserAdapter(Context applicationContext, ArrayList<UserPOJO> users) {
        this.context = context;
        this.users = users;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.useritem,parent,false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        holder.txtUsername.setText(users.get(position).getUsername());
        holder.txtPassword.setText(users.get(position).getPassword());
    }

    @Override
    public int getItemCount() {
        return users.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder {
        TextView txtUsername, txtPassword;
        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            txtUsername = itemView.findViewById(R.id.txtUsername);
            txtPassword = itemView.findViewById(R.id.txtPassword);
        }
    }
}


---------------------------------
# <!--UserPOJO.java-->

package com.rku.databaserecycleview;

public class UserPOJO {
    private String username;
    private String password;

    public UserPOJO(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
------------------------

# <!--AndroidManifest-->

<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.rku.databaserecycleview">

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.DatabaseRecycleView">
        <activity
            android:name=".Registration"
            android:exported="false"
            android:label="Registration"
            android:parentActivityName=".Dashboard"/>
        <activity
            android:name=".Dashboard"
            android:label="Demo Database"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />

                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
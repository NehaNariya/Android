package com.rku.databaserecycleview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends AppCompatActivity {

    EditText edtUsername, edtPassword;
    Button btnRegister;
    DBHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        edtUsername = findViewById(R.id.edtUsername);
        edtPassword = findViewById(R.id.edtPassword);
        btnRegister = findViewById(R.id.btnRegister);
        helper = new DBHelper(this);
        btnRegister.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                validateForm();
            }

            private void validateForm() {
                String valUsername = edtUsername.getText().toString().trim();
                String valPassword = edtPassword.getText().toString();

                if(valUsername.equals("") || valPassword.equals("")){
                   Toast.makeText(Registration.this,"Username or Password can not empty.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(valPassword.length()<6){
                    Toast.makeText(Registration.this,"Password must be greter then 6.",Toast.LENGTH_SHORT).show();
                    return;
                }

                ContentValues values = new ContentValues();
                values.put(MYUtil.COL_USERNAME,valUsername);
                values.put(MYUtil.COL_PASSWORD,valPassword);

                SQLiteDatabase db = helper.getWritableDatabase();
                db.insert(MYUtil.TBL_NAME,null,values);
  //              db.close();
                Toast.makeText(Registration.this, "Record Added Successfully", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Registration.this, Dashboard.class));
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
   //     super.onBackPressed();
        Toast.makeText(this,"Back Button Pressed",Toast.LENGTH_SHORT).show();
    }
}
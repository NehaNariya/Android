package com.rku.databaserecycleview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class Dashboard extends AppCompatActivity {

    FloatingActionButton btnAddRecord;
    RecyclerView recyclerView;
    ArrayList<UserPOJO> users;
    UserAdapter adapter;
    DBHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        intUI();
    }

    private void intUI() {
        helper = new DBHelper(this);
        recyclerView = findViewById(R.id.recycleView);
     //   users = new ArrayList<UserPOJO>();
        users = fetchUsersFromDatabase();
        adapter = new UserAdapter(getApplicationContext(),users);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new DividerItemDecoration(Dashboard.this, DividerItemDecoration.VERTICAL));
        recyclerView.setAdapter(adapter);

        adapter.notifyDataSetChanged();

        btnAddRecord = findViewById(R.id.btnAddRecord);
        btnAddRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Dashboard.this,Registration.class));
                finish();
            }
        });
    }

    private ArrayList<UserPOJO> fetchUsersFromDatabase() {
        ArrayList<UserPOJO> usersList = new ArrayList<UserPOJO>();
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor cursor = db.query(MYUtil.TBL_NAME,null,null,null,null,null,null);

        if(cursor.getCount()>0){
            cursor.moveToFirst();
            do{
                String valuser = cursor.getString(1);
                String valpassword = cursor.getString(2);
                usersList.add(new UserPOJO(valuser,valpassword));
            }while(cursor.moveToNext());
        }
        return usersList;
    }
}
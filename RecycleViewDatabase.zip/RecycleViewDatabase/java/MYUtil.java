package com.rku.databaserecycleview;

public class MYUtil {
    public static final String DB_NAME = "university1";
    public static final int DB_VERSION = 1;
    public static final String TBL_NAME = "student1";

    public static final String COL_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    public static final String SQL_CREATE_TBL = "" +
            "CREATE TABLE IF NOT EXISTS "+ TBL_NAME + "(" +
            COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"+
            COL_USERNAME + " VARCHAR,"+
            COL_PASSWORD + " VARCHAR)";
}

package com.rku.tutorial__04;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    TextInputEditText edtUsername , edtPassword;
    Button btnLogin;
    View rootLoginLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init_view();

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String valUsername = edtUsername.getText().toString();
                String valPassword = edtPassword.getText().toString();

                if(Patterns.EMAIL_ADDRESS.matcher(valUsername).matches() &&
                        valUsername.equals("admin@gmail.com") && valPassword.equals("123456"))
                {
                    startActivity(new Intent(MainActivity.this,WelcomeActivity.class));
                    Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                    finish();
                }
                else
                {
                    Snackbar.make(rootLoginLayout, "Login Failed", BaseTransientBottomBar.LENGTH_LONG).show();
                }
            }
        });
    }

    private void init_view() {
        edtUsername = findViewById(R.id.edtUsername);
        edtPassword = findViewById(R.id.edtPassword);
        btnLogin = findViewById(R.id.btnLogin);
        rootLoginLayout = findViewById(R.id.rootLoginLayout);
    }
}
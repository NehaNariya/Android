package com.rku.tutorial_07;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    TextInputEditText edtUsername, edtPassword;
    DBHelper dbHelper;
    TextView txtData;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DBHelper(getApplicationContext());
        edtUsername = findViewById(R.id.edtUsername);
        edtPassword = findViewById(R.id.edtPassword);
        btnLogin = findViewById(R.id.btnLogin);
        txtData = findViewById(R.id.txtData);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String valUsername = edtUsername.getText().toString();
                String valPassword = edtPassword.getText().toString();

                SQLiteDatabase db = dbHelper.getReadableDatabase();
                ContentValues values = new ContentValues();

                values.put("username", valUsername);
                values.put("password", valPassword);

                db.insert("student", null, values);
                displayData();
            }

        });
    }
            private void displayData() {
                SQLiteDatabase db = dbHelper.getReadableDatabase();
                Cursor cursor = db.query("student",new String[]{"username","password"},"id<?",new String[]{"10"},null,null,"id desc");
                Log.i("count",""+cursor.getCount());

                if (cursor.getCount() > 0)
                {
                    cursor.moveToFirst();
                    String data = "";

                    do {
                        data = data + cursor.getString(0) + " - "+ cursor.getString(1)+"\n";
                    }
                    while (cursor.moveToNext());
                    txtData.setText(data);
                }

    }
}





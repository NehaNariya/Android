package com.rku.recycleviewdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ClipData;
import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView RCView;
    ArrayList<Items> list;
    CustomRecyclerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RCView = findViewById(R.id.RCView);
        list = generateData();
        adapter = new CustomRecyclerAdapter(list);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        RCView.setLayoutManager(mLayoutManager);
        RCView.setItemAnimator(new DefaultItemAnimator());
        RCView.addItemDecoration(new DividerItemDecoration(MainActivity.this,DividerItemDecoration.VERTICAL));
        RCView.setAdapter(adapter);

        adapter.notifyDataSetChanged();
    }
    private ArrayList<Items> generateData() {
        ArrayList<Items> list = new ArrayList<Items>();
        list.add(new Items("Items 1","Description 1"));
        list.add(new Items("Items 2","Description 2"));
        list.add(new Items("Items 3","Description 3"));
        list.add(new Items("Items 4","Description 4"));
        list.add(new Items("Items 5","Description 5"));
        list.add(new Items("Items 6","Description 6"));
        list.add(new Items("Items 7","Description 7"));
        list.add(new Items("Items 8","Description 8"));
        list.add(new Items("Items 9","Description 9"));
        list.add(new Items("Items 10","Description 10"));
        list.add(new Items("Items 11","Description 11"));
        list.add(new Items("Items 12","Description 12"));
        list.add(new Items("Items 13","Description 13"));
        list.add(new Items("Items 14","Description 14"));
        list.add(new Items("Items 15","Description 15"));
        return list;
    }
}

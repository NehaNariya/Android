package com.rku.tutorial_06;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class WelcomeActivity extends AppCompatActivity {


    TextView t3;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        preferences=getSharedPreferences("settings",MODE_PRIVATE);
        editor =preferences.edit();
        t3=findViewById(R.id.textView3);
        Intent intent = getIntent();

        String username = intent.getStringExtra("username");
        t3.setText("Welcome, "+username);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.master,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        String title = item.getTitle().toString();
        Toast.makeText(this,title+"Clicked",Toast.LENGTH_LONG).show();

        editor.remove("username");
        editor.commit();
        startActivity(new Intent(WelcomeActivity.this,MainActivity.class));
        finish();

        return super.onOptionsItemSelected(item);
    }
}
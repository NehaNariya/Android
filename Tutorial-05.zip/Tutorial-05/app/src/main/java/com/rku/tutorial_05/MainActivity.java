package com.rku.tutorial_05;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextInputEditText edtFirstname, edtLastname, edtUsername, edtPassword;
    RadioGroup radGroupGender;
    RadioButton radBtnMale, radBtnFemale;
    Spinner spiCityList;
    Switch swcBranch;
    CheckBox chkTerms;
    Button btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init_views();
        
    }

    private void init_views() {
        edtFirstname = findViewById(R.id.edtFirstname);
        edtLastname = findViewById(R.id.edtLastname);
        edtUsername = findViewById(R.id.edtUsername);
        edtPassword = findViewById(R.id.edtPassword);
        radGroupGender = findViewById(R.id.radGroupGender);
        radBtnMale = findViewById(R.id.radBtnMale);
        radBtnFemale = findViewById(R.id.radBtnFemale);
        spiCityList = findViewById(R.id.spiCityList);
        swcBranch = findViewById(R.id.swcBranch);
        chkTerms = findViewById(R.id.chkTerms);
        btnRegister = findViewById(R.id.btnRegister);

        btnRegister.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        String valFirstName = edtFirstname.getText().toString().trim();
        String valLastname = edtLastname.getText().toString().trim();
        String valUsername = edtUsername.getText().toString().trim();
        String valPassword = edtPassword.getText().toString().trim();

        RadioButton tempRadio = findViewById(radGroupGender.getCheckedRadioButtonId());
        String valGender = tempRadio.getText().toString();

        String valCity = spiCityList.getSelectedItem().toString();
        String Branch = "";
        String status = "";

        if (swcBranch.isChecked()) {
            Branch = swcBranch.getTextOn().toString();
        } else {
            Branch = swcBranch.getTextOff().toString();
        }

        if (chkTerms.isChecked()) {
            status = "Active";
            Toast.makeText(this, "Welcome", Toast.LENGTH_SHORT).show();
        } else {
            status = "Inactive";
            //Toast.makeText(this,"Welcome",Toast.LENGTH_SHORT).show();
        }


        Intent intent = new Intent(MainActivity.this, ResultActivity.class);
        intent.putExtra("firstname", valFirstName);
        intent.putExtra("lastname", valLastname);
        intent.putExtra("username", valUsername);
        intent.putExtra("password", valPassword);
        intent.putExtra("gender", valGender);
        intent.putExtra("city", valCity);
        startActivity(intent);
    }
}
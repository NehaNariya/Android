package com.rku.tutorial_05;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {

    TextView txtResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        txtResult = findViewById(R.id.txtResult);

        Intent intent = getIntent();
        String firstname = intent.getStringExtra("firstname");
        String lastname = intent.getStringExtra("lastname");
        String username = intent.getStringExtra("username");
        String password = intent.getStringExtra("password");
        String gender = intent.getStringExtra("gender");
        String city = intent.getStringExtra("city");
        String branch = intent.getStringExtra("branch");
        String status = intent.getStringExtra("status");

        txtResult.setText(
                "Name : " + firstname + " " + lastname + "\n" +
                        "Username : " + username + "\n" +
                        "Password : " + password + "\n" +
                        "Gender : " + gender + "\n" +
                        "City : " + city + "\n" +
                        "Branch : " + branch + "\n" +
                        "Terms & Condition : " + status
        );
    }
}